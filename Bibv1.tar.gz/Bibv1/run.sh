#!/bin/bash
#oualid
java --module-path "javafx-sdk-23.0.2/lib/:mysql-connector-9.1.0/" --add-modules javafx.controls,javafx.graphics,javafx.fxml -jar BibV1.jar

